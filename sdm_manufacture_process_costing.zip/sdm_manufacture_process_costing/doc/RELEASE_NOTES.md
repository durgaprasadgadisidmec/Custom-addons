## Module <manufacture_process_costing>

#### 2.12.2023
#### Version 16.0.1.0.0
#### ADD
- Initial commit for Process Cost of Manufacturing Orders
