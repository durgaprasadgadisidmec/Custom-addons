from . import patient
from . import saleorder
from . import doctor
from . import res_partner