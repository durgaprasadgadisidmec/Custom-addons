from . import patient_wizard
from . import discharge_wizard
from . import sale_order_wizard
